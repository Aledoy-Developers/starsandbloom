<?php 

include('connect.php');
// $password = 'content'; // The plain text password
// $hashed_password = password_hash($password, PASSWORD_BCRYPT);

// // Store $hashed_password in the database

// mysqli_query($conn,"UPDATE login SET password = '$hashed_password'");